package com.epam.task6.data.factory;

public enum BookField {
    TITLE,
    AUTHORS,
    PUBLISHER,
    YEAR,
    NUMBER_PAGES,
}
